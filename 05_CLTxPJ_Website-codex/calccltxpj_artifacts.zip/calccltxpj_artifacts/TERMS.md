# Termos de Uso — CalcCLTxPJ

Última atualização: 2025-12-20

1. **Finalidade educacional:** o simulador fornece estimativas e comparações, não aconselhamento financeiro/jurídico/contábil.
2. **Responsabilidade do usuário:** decisões devem ser validadas com profissionais quando necessário.
3. **Disponibilidade:** o serviço pode sofrer alterações, interrupções ou descontinuação.
4. **Propriedade:** CalcCLTxPJ e seus materiais associados são protegidos por direitos autorais quando aplicável.
5. **Contato:** defina aqui um e-mail oficial (ex.: suporte@calccltxpj.com.br).
