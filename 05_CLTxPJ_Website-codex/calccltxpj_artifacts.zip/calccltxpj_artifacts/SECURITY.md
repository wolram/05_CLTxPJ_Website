# Security Policy

## Reporting a Vulnerability
If you discover a security vulnerability, do not open a public issue.
Contact the maintainer privately with details and reproduction steps.

## Key rule
- Never expose API keys in client-side code.
