# CONTENT_PLAN — Build in Public (CalcCLTxPJ)

## Cadência (mínimo sustentável)
- 2 posts/semana (LinkedIn)
- 2 updates curtos/semana (X/Threads)
- 1 Ship Log/semana (blog)

## Template de post
- Ship: o que foi entregue
- Proof: print/URL
- Learn: 1 aprendizado
- Next: próximo passo
- Ask: pedido claro (testar, feedback, compartilhar)

## Ideias de posts (primeiras 6)
1. Por que criei o CalcCLTxPJ
2. CLT x PJ: quais variáveis realmente mudam o jogo
3. Como medir funil: simulador → clique → App Store
4. O que aprendi construindo a landing em Next.js + Tailwind
5. IA como “consultor”: limites e responsabilidade
6. Antes/depois do novo ícone e screenshots do app (ASO)
