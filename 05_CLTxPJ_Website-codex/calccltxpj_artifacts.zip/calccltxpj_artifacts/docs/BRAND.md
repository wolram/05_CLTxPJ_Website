# BRAND — CalcCLTxPJ

## Nome
- Marca: CalcCLTxPJ
- App Store: Calculadora CLT x PJ

## Tom de voz
- Claro, direto, sem jargão
- Educacional, sem prometer “mágica”
- Foco em decisão e trade-offs

## Promessa (draft)
"Descubra se CLT ou PJ compensa no seu cenário — em segundos."

## CTAs
- "Baixar na App Store"
- "Simular agora"
- "Gerar análise do cenário"
