# LINEAR_SETUP — CalcCLTxPJ

## Projects
- P0 — Web (calccltxpj.com.br)
- P1 — iOS App (Calculadora CLT x PJ)
- P2 — Growth (SEO/Conteúdo/Distribuição)
- P3 — IA (Gemini proxy + qualidade)

## Workflow
Backlog → Planned → In Progress → Review → Done (+ Blocked opcional)

## Custom fields
- Impacto (ROI): High / Medium / Low
- Esforço: S / M / L
- Categoria: Dev / SEO / Content / Infra / Design
- Canal: Website / App Store / Blog / LinkedIn / X

## WIP
Máximo 3 issues em In Progress.
