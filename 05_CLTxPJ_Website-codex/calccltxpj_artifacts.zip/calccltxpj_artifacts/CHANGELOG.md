# CHANGELOG

All notable changes to this project will be documented in this file.

The format is based on *Keep a Changelog* and this project adheres to *Semantic Versioning*.

## [Unreleased]
### Added
- 

### Changed
- 

### Fixed
- 

## [0.1.0] - YYYY-MM-DD
### Added
- Initial website with simulator + CTA.
