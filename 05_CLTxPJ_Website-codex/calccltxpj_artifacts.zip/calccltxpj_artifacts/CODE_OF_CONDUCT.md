# Code of Conduct

Be respectful. No harassment. Assume good intent.
This project follows a simple, community-friendly conduct policy.
